module.exports = {
    tabWidth: 4,
    singleQuote: true,
    trailingComma: 'all',
    endOfLine: 'auto',
};
