// import {auth} from "../helpers/auth";
import { AutoTestUIWine } from "../helpers/newtst";

describe('access ui test', () => {
    const lite = new AutoTestUIWine()
    it ('Test user authorization', () => {
        cy.visit("https://dev.wineincognito.ru/")
        lite.checkText.should('exist').and('be.visible')
        lite.checkEmail.should('exist').and('be.visible')
        lite.checkPassword.should('exist').and('be.visible')
        lite.checkBtnInput.should('contain', 'Вход')
        lite.checkType.should('have.attr', 'placeholder', 'Введите свою почту')
        lite.checkTypePassword.should('contain', 'Пароль')
        lite.checkTypePassword.click().type('abcde')
        lite.checkHidePassword.should('contain', 'Hide password')

        

    })
    
      


 })