export class AutoTestUIWine {
    get check (){
        return cy.get('.container').first()
    }
    get checkText(){
        return this.check.find('.title').first()
    }
    get checkEmailandPassword(){
        return this.check.find('.common-content')
    }
    get checkEmail(){
        return this.checkEmailandPassword.find('.required').first().find('input')
    }
    get checkPassword(){
        return this.checkEmailandPassword.find('.form-control__label').first()
    }
    get checkBtnInput(){
        return this.check.find('.common-footer').first().find('sl-button').first()
    }
    get checkType(){
        return this.checkEmailandPassword.find('.required').first().find('.form-control-input').first().find('input--medium').first()
        
    }
    get checkTypePassword(){
        return this.checkEmailandPassword.find('.form-control-input').eq(2).find('.input__control').eq(2)
    }
    get checkHidePassword(){
        return this.checkEmailandPassword.find('.form-control-input').eq(2).find('.input__password-toggle')
    }
    
}